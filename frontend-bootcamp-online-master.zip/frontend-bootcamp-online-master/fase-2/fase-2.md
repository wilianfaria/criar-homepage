# Fase 2 - Intermediário

[![bit-octocat.png](https://i.postimg.cc/JzxhSxxy/bit-octocat.png)](https://postimg.cc/hXJgd9Hg)

## O que eu vou aprender?! 📕

Nessa fase, você terá que escolher qual framework gostaria de aprender: 

- Vue 
- React 
- Angular
- TypeScript

Depois que escolher o framework que deseja aprender, você precisará aprender antes:

- Node.js
- MongoDb

No decorrer do Bootcamp, incluiremos leituras recomendadas, para que possam auxiliar nos seus estudos.
Lembrando que, para seguir para a próxima fase, você deverá abrir uma **[ISSUE AQUI](https://github.com/glaucia86/frontend-bootcamp-online/issues)** com o link do seu projeto.

## Agenda 📘

| Parte  |  Tópico |   
|---|--- |